# Card Hover with :has()

A Pen created on CodePen.io. Original URL: [https://codepen.io/choogoor/pen/RwBKZey](https://codepen.io/choogoor/pen/RwBKZey).

Card hover concept with :has() pseudo selector. 